from urllib import request
from urllib import error
import re
import excel


excel_name = 'excel/douban_hot_review.xls'
sheet_name = '豆瓣影评'


'''创建一个excel'''
douban_excel = excel.Excel(excel_name,sheet_name)

class DouBanSpider(object):
    '''
    数据成员：
    page:        表示当前处理的页面
    cur_url:     表示当前准备抓取的页面
    '''
    def __init__(self):
        self.page = 1
        self.cur_url = 'http://movie.douban.com/top250?start={page}&filter=&type='#{page}是可以代替的
        self.top = 0
        print('开始工作')

    '''
    cur_page：表示当前处理的界面
    return:返回抓取的整个界面的HTML（uicode编码）
    '''
    def get_html(self,cur_page):
        url = self.cur_url
        try:
            page = request.urlopen(url.format(page = (cur_page - 1) * 25)).read().decode("utf-8")
        except error.URLError as e:
            if hasattr(e,'code'):
                print("HTTPError: the server could not deal with the request")
                print("Error code: %s"% e.code)
            elif hasattr(e,'reason'):
                print("URLError: failed to reach the server")
                print("Reason: %s"% e.reason)
        return page

    '''
    page:表示当前抓取到的html文件
    功能：将匹配到的内容写入到excel文件中
    '''
    def find_Info(self,page):
        movie_items = re.findall(r'<span.*?class="title">(.*?)</span>',page,re.S)
        number = 0
        for index,item in enumerate(movie_items):
         #   print('编号：' + str(index))
         #   print('编号对应的字符串：' + str(item))
            if item.find(" ") != 0 and item.find("&nbsp") == -1:
                douban_excel.write(self.top,0,item)
                self.top += 1
                print('第' + str(self.top) + '个电影名是：' + str(item))
        douban_excel.save()

    def start_spider(self):
        '''爬虫入口'''
        while self.page <= 10:
            page = self.get_html(self.page)
            self.find_Info(page)
            self.page += 1

def main():
    '''程序入口'''
    spider = DouBanSpider()
    spider.start_spider()

if __name__ == '__main__':
    main()






